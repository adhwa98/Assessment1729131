# facemask > 2022-08-01 3:58pm
https://universe.roboflow.com/object-detection/facemask-wq14n

Provided by Roboflow
License: CC BY 4.0

